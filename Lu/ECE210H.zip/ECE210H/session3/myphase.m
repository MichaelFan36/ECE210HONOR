function [ z_phase ] = myphase( z )
    % This function returns the phase of the complex number z

    z_phase = angle(z);

    end